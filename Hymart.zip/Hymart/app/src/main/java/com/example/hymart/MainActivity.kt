package com.example.hymart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonMenu = findViewById<Button>(R.id.button_menu)
        buttonMenu.setOnClickListener {
            Toast.makeText(this,"Home",Toast.LENGTH_SHORT).show()
        }
        val buttonExit = findViewById<Button>(R.id.button_exit)
        buttonExit.setOnClickListener {
            Toast.makeText(this,"Exit",Toast.LENGTH_SHORT).show()
        }


    }
}